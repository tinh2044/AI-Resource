# RNN and LSTM example

Implemented for getting to know these models better. The RNN is based on [the minimal example by @karpathy](https://gist.github.com/karpathy/d4dee566867f8291f086), the LSTM is built on top of that.
